tinyMCE.addI18n('en.umisimple',{
bold_desc:"Bold (Ctrl+B)",
italic_desc:"Italic (Ctrl+I)",
underline_desc:"Underline (Ctrl+U)",
justifyleft_desc:"Justify Left",
justifycenter_desc:"Justify Center",
justifyright_desc:"Justify Right",
striketrough_desc:"Strikethrough",
bullist_desc:"Unordered list",
numlist_desc:"Ordered list",
undo_desc:"Undo (Ctrl+Z)",
redo_desc:"Redo (Ctrl+Y)",
link_desc:"Create link",
unlink_desc:"Delete link",
image_desc:"Insert image",
cleanup_desc:"Cleanup messy code"
});