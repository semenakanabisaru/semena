// EN lang variables

tinyMCE.addI18n('en.imagemanager',{
toggle_btn : 'Images library',
desc : 'Images',
resize_title : 'Image size',
resize_general : 'Image size',
panel_size : 'Library panel size',
orig_size : 'Original size',
user_size : 'Thumbnail:',
size_width: 'Width',
size_height: 'Height',
save_proportions: 'Save proportion',

lbl_remove_img_title : 'Delete image?',
lbl_remove_img_confirm :  'Are you sure that you want to delete this image?',
lbl_dont_ask : "don't ask again",
lbl_delete : 'Delete',
lbl_create : 'Create',
lbl_cancel : 'Cancel',
lbl_upload : 'Upload',

lbl_hide : 'Hide',
lbl_move_help : 'Drag and drop image into editor',
lbl_upload_image : 'Upload image file',
lbl_upload_error : 'Upload file error.',

lbl_enter_folder_name: 'Enter new folder name'

});
